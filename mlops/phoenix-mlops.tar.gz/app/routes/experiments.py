from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

# HTML component routes (no prefix needed for these)
@router.get("/components/experiments/create-modal", response_class=HTMLResponse)
async def get_create_modal(request: Request):
    return templates.TemplateResponse(
        "components/experiments/create-modal.html",
        {"request": request}
    )

@router.get("/components/experiments/compare-modal", response_class=HTMLResponse)
async def get_compare_modal(request: Request):
    return templates.TemplateResponse(
        "components/experiments/compare-modal.html",
        {"request": request}
    )

@router.get("/components/experiments/experiment-details", response_class=HTMLResponse)
async def get_experiment_details(request: Request):
    return templates.TemplateResponse(
        "components/experiments/experiment-details.html",
        {"request": request}
    )

@router.get("/components/experiments/overview-tab", response_class=HTMLResponse)
async def get_overview_tab(request: Request):
    return templates.TemplateResponse(
        "components/experiments/overview-tab.html",
        {"request": request}
    )

# API routes (will have /api/v1 prefix)
@router.get("/experiments/filter")
async def filter_experiments():
    # Mock data for demonstration
    return {
        "experiments": [
            {
                "id": "exp_1",
                "name": "ChurnModel XGBoost",
                "status": "active",
                "framework": "XGBoost",
                "accuracy": 87.5,
                "last_updated": "2024-01-17 14:22 UTC"
            },
            # Add more mock experiments...
        ]
    }