from fastapi import APIRouter, Request, HTTPException, Form, UploadFile, File, Cookie
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from ..models.governance import ModelRegistration, ModelSource, ModelMetadata, ModelDocumentation
import logging
from typing import Optional
import json
import uuid
from starlette.responses import Response

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")
logger = logging.getLogger(__name__)

# Store registration data temporarily (in production, use a proper database)
registration_data = {}

def get_or_create_session_id(request: Request, response: Response) -> str:
    session_id = request.cookies.get("session_id")
    if not session_id:
        session_id = str(uuid.uuid4())
        response.set_cookie(key="session_id", value=session_id, httponly=True)
    return session_id

@router.get("/", response_class=HTMLResponse)
async def governance_home(request: Request):
    return templates.TemplateResponse("pages/governance/index.html", {"request": request})

@router.get("/register", response_class=HTMLResponse)
async def register_model(request: Request, response: Response):
    session_id = get_or_create_session_id(request, response)
    return templates.TemplateResponse("pages/governance/register.html", {"request": request})

@router.get("/register/step1", response_class=HTMLResponse)
async def register_step1(request: Request, response: Response):
    session_id = get_or_create_session_id(request, response)
    return templates.TemplateResponse("pages/governance/components/step1.html", {"request": request})

@router.get("/register/step2", response_class=HTMLResponse)
async def register_step2(request: Request, response: Response):
    session_id = get_or_create_session_id(request, response)
    return templates.TemplateResponse("pages/governance/components/step2.html", {"request": request})

@router.get("/register/step3", response_class=HTMLResponse)
async def register_step3(request: Request, response: Response):
    session_id = get_or_create_session_id(request, response)
    return templates.TemplateResponse("pages/governance/components/step3.html", {"request": request})

@router.get("/register/step4", response_class=HTMLResponse)
async def register_step4(request: Request, response: Response):
    """Handle the review step of model registration"""
    try:
        session_id = get_or_create_session_id(request, response)
        registration = registration_data.get(session_id, {})
        return templates.TemplateResponse(
            "pages/governance/components/step4.html",
            {"request": request, "registration": registration}
        )
    except Exception as e:
        logger.error(f"Error in review step: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/register/save-step")
async def save_step_data(
    request: Request,
    response: Response,
    step: int = Form(...),
    data: str = Form(...)
):
    """Save data for each step and return the next step's template"""
    try:
        session_id = get_or_create_session_id(request, response)
        
        if session_id not in registration_data:
            registration_data[session_id] = {}

        step_data = json.loads(data)
        registration_data[session_id].update(step_data)

        # Return the next step's template based on current step
        if step == 1:
            return templates.TemplateResponse(
                "pages/governance/components/step2.html",
                {"request": request}
            )
        elif step == 2:
            return templates.TemplateResponse(
                "pages/governance/components/step3.html",
                {"request": request}
            )
        elif step == 3:
            return templates.TemplateResponse(
                "pages/governance/components/step4.html",
                {"request": request, "registration": registration_data[session_id]}
            )

        return JSONResponse(content={
            "status": "success",
            "message": f"Step {step} data saved successfully"
        })
    except Exception as e:
        logger.error(f"Error saving step data: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"status": "error", "message": str(e)}
        )

@router.post("/register/submit")
async def submit_registration(request: Request, response: Response):
    """Handle the final submission of the model registration"""
    try:
        session_id = get_or_create_session_id(request, response)
        registration = registration_data.get(session_id)
        if not registration:
            raise HTTPException(status_code=404, detail="Registration data not found")

        # Validate the complete registration
        model_registration = ModelRegistration(**registration)

        # TODO: Implement the actual registration process
        # 1. Save to database
        # 2. Handle model artifacts
        # 3. Create governance record
        # 4. Trigger necessary workflows

        # Clear the temporary data
        registration_data.pop(session_id, None)
        response.delete_cookie(key="session_id")

        return templates.TemplateResponse(
            "pages/governance/components/success.html",
            {
                "request": request,
                "message": "Model registration submitted successfully",
                "model_name": model_registration.metadata.name
            }
        )
    except Exception as e:
        logger.error(f"Error in registration submission: {str(e)}")
        return templates.TemplateResponse(
            "pages/governance/components/error.html",
            {
                "request": request,
                "error": str(e)
            }
        )

# ... existing routes ...