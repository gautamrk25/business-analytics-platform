# app/routes/deploy.py
from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from pathlib import Path
from fastapi.responses import HTMLResponse

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/")
async def deploy_home(request: Request):
    return templates.TemplateResponse("pages/deploy/index.html", {"request": request})

@router.get("/configure/new")
@router.get("/configure/{model_id}")
async def deploy_configure(request: Request, model_id: str = "new"):
    model_data = {
        "id": model_id,
        "name": "ChurnModel",
        "version": "1.0",
        "framework": "TensorFlow",
        "recommended_machine": "n1-standard-4",
        "recommended_gpu": "nvidia-tesla-t4"
    }
    return templates.TemplateResponse(
        "pages/deploy/configure.html", 
        {"request": request, "model": model_data}
    )

@router.get("/endpoints")
async def deploy_endpoints(request: Request):
    return templates.TemplateResponse("pages/deploy/endpoints.html", {"request": request})

@router.get("/upload", response_class=HTMLResponse)
async def upload_model(request: Request):
    return templates.TemplateResponse(
        "pages/deploy/upload.html",
        {"request": request}
    )

@router.post("/api/upload")
async def handle_upload(request: Request):
    # This will be implemented later to handle the actual file upload
    try:
        # TODO: Implement actual file upload logic
        return {"modelId": "temp-model-id"}
    except Exception as e:
        return {"error": str(e)}
    

@router.get("/configure")
async def configure_deployment(request: Request):
    """
    Handle the configuration page after model upload
    """
    return templates.TemplateResponse(
        "pages/deploy/configure.html",
        {"request": request}
    )

# Note: You can keep the existing /deploy/configure route as an alias
@router.get("/deploy/configure")
async def configure_deployment_alt(request: Request):
    return await configure_deployment(request)

@router.get("/progress")
async def deployment_progress(request: Request):
    return templates.TemplateResponse(
        "pages/deploy/progress.html",
        {"request": request}
    )

@router.get("/deploy")
@router.get("/deploy/models")
async def deploy_models(request: Request):
    return templates.TemplateResponse(
        "pages/deploy/index.html",
        {"request": request}
    )

@router.get("/settings")
async def deployment_settings(request: Request):
    """
    Handle the deployment settings page
    """
    # Mock settings data - in real implementation, this would come from a database
    settings_data = {
        "environment": "development",
        "region": "us-east",
        "instance_type": "medium",
        "storage": 20,
        "min_instances": 1,
        "max_instances": 5
    }
    return templates.TemplateResponse(
        "pages/deploy/settings.html",
        {"request": request, "settings": settings_data}
    )

@router.post("/settings")
async def update_deployment_settings(request: Request):
    """
    Handle the deployment settings update
    """
    # TODO: Implement settings update logic
    try:
        form_data = await request.form()
        # Process and save settings
        return {"success": True, "message": "Settings updated successfully"}
    except Exception as e:
        return {"success": False, "error": str(e)}