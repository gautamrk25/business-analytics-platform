from flask import Blueprint, render_template

develop = Blueprint('develop', __name__)

@develop.route('/')
def index():
    return render_template('pages/develop/index.html')

@develop.route('/project/<project_id>')
def project_details(project_id):
    # In the future, we'll fetch project data here
    return render_template('pages/develop/project_details.html', project_id=project_id) 