from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/")
async def monitor_home(request: Request):
    return templates.TemplateResponse("pages/monitor/index.html", {"request": request})

@router.get("/create-model-monitor")
async def create_model_monitor(request: Request):
    return templates.TemplateResponse(
        "pages/monitor/create-model-monitor.html",
        {"request": request}
    )
