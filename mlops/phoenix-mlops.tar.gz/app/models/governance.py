from pydantic import BaseModel, Field, model_validator, field_validator
from typing import Optional, List, Dict
from enum import Enum
from datetime import datetime

class ModelFramework(str, Enum):
    TENSORFLOW = "tensorflow"
    PYTORCH = "pytorch"
    SCIKIT_LEARN = "scikit-learn"
    XGBOOST = "xgboost"
    ONNX = "onnx"
    OTHER = "other"

class ModelSource(str, Enum):
    VERTEX_AI = "vertex_ai"
    DIRECT_UPLOAD = "direct_upload"

class ModelMetadata(BaseModel):
    """Base model for ML model metadata"""
    name: str = Field(..., description="Unique name for the model")
    description: str = Field(..., description="Detailed description of the model")
    owner: str = Field(..., description="Model owner or team")
    business_unit: str = Field(..., description="Business unit or team")
    business_objective: str = Field(..., description="Business objective of the model")
    intended_use: str = Field(..., description="Intended use and scope")
    framework: ModelFramework
    framework_version: str
    tags: Optional[List[str]] = Field(default=[], description="Tags for categorization")
    training_data_source: Optional[str] = Field(None, description="Source of training data")
    repository_link: Optional[str] = Field(None, description="Link to code repository")
    data_version: Optional[str] = Field(None, description="Version of training data")
    hyperparameters: Optional[Dict] = Field(default={}, description="Model hyperparameters")
    evaluation_metrics: Optional[Dict] = Field(default={}, description="Model evaluation metrics")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @field_validator('name')
    def validate_name(cls, v: str) -> str:
        if not v.replace('_', '').replace('-', '').isalnum():
            raise ValueError('Name must contain only alphanumeric characters, underscores, and hyphens')
        return v

class ModelDocumentation(BaseModel):
    """Model for comprehensive model documentation"""
    executive_summary: str = Field(..., min_length=50, description="Brief overview of the model's purpose and business impact")
    data_description: str = Field(..., min_length=50, description="Detailed description of training and evaluation data")
    model_architecture: str = Field(..., min_length=50, description="Technical details about model architecture and implementation")
    training_process: str = Field(..., min_length=50, description="Description of training procedure and resources")
    validation_results: str = Field(..., min_length=50, description="Summary of model performance and validation")
    assumptions_limitations: str = Field(..., min_length=50, description="Model assumptions and known limitations")
    ethical_considerations: str = Field(..., min_length=50, description="Discussion of ethical implications and mitigations")
    explainability: str = Field(..., min_length=50, description="Explanation of model interpretability")
    supporting_docs: Optional[List[str]] = Field(default=[], description="List of supporting document filenames")

    @field_validator('executive_summary', 'data_description', 'model_architecture', 'training_process', 
                    'validation_results', 'assumptions_limitations', 'ethical_considerations', 'explainability')
    @classmethod
    def validate_content(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Field cannot be empty")
        return v.strip()

class ModelRegistration(BaseModel):
    """Model for registering a new model"""
    source: ModelSource
    metadata: ModelMetadata
    documentation: Optional[ModelDocumentation] = None
    vertex_ai_model_id: Optional[str] = Field(None, description="Vertex AI Model ID if source is vertex_ai")
    model_artifacts: Optional[Dict] = Field(None, description="Model artifact information for direct uploads")

class ValidationResult(BaseModel):
    """Model for validation results"""
    passed: bool
    message: str
    details: Optional[Dict] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ModelValidation(BaseModel):
    """Model for model validation request"""
    model_id: str
    validation_type: str
    parameters: Optional[Dict] = None
    results: Optional[List[ValidationResult]] = None 