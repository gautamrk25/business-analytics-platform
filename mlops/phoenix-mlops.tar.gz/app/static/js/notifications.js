function notificationSystem() {
    return {
        notifications: [],
        addNotification(message, type = 'info') {
            this.notifications.push({
                id: Date.now(),
                message,
                type
            });
            setTimeout(() => this.removeNotification(this.notifications[0].id), 3000);
        },
        removeNotification(id) {
            this.notifications = this.notifications.filter(notification => notification.id !== id);
        }
    }
} 