document.addEventListener('alpine:init', () => {
    Alpine.data('notificationSystem', () => ({
        notifications: [],
        add(notification) {
            const id = Date.now();
            notification.id = id;
            notification.visible = true;
            
            this.notifications.push(notification);

            // Auto remove after duration (default 5000ms)
            setTimeout(() => {
                this.remove(id);
            }, notification.duration || 5000);
        },
        remove(id) {
            const notification = this.notifications.find(n => n.id === id);
            if (notification) {
                notification.visible = false;
                setTimeout(() => {
                    this.notifications = this.notifications.filter(n => n.id !== id);
                }, 300);
            }
        }
    }));
});

// Add a helper function to make triggering notifications easier
function showNotification(type, title, message, duration = 5000) {
    window.dispatchEvent(new CustomEvent('notification', {
        detail: {
            type,
            title,
            message,
            duration
        }
    }));
}

// Example usage:
// showNotification('success', 'Success!', 'Operation completed successfully');
// showNotification('error', 'Error!', 'Something went wrong');
// showNotification('info', 'Info', 'Here is some information');
// showNotification('warning', 'Warning!', 'This is a warning message'); 