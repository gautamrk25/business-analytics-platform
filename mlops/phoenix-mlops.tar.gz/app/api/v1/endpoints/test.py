from fastapi import APIRouter, HTTPException

router = APIRouter()

@router.get("/test/notification-page")
async def test_notification_page():
    return {"template": "pages/test/notification-test.html"}

@router.get("/api/test/error")
async def test_error():
    # This endpoint always raises an error to test error notifications
    raise HTTPException(status_code=500, detail="Test error notification") 