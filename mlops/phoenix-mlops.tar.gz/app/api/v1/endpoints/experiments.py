from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any

router = APIRouter()

@router.get("/experiments")
async def get_experiments() -> str:
    """Return experiments list HTML"""
    # Mock data for demonstration
    experiments = [
        {"id": 1, "name": "Model Training A", "status": "Completed", "accuracy": "92%"},
        {"id": 2, "name": "Model Training B", "status": "Running", "accuracy": "88%"},
    ]
    
    # Return HTML for HTMX to swap
    return """
    <div class="space-y-4">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Accuracy</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    """ + "".join([f"""
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{exp['id']}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{exp['name']}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{exp['status']}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{exp['accuracy']}</td>
                    </tr>
                    """ for exp in experiments]) + """
                </tbody>
            </table>
        </div>
    </div>
    """

@router.get("/metrics/training")
async def get_training_metrics() -> str:
    """Return training metrics visualization HTML"""
    return """
    <div class="h-64 bg-white rounded-lg border p-4">
        <canvas id="trainingChart"></canvas>
        <script>
            const ctx = document.getElementById('trainingChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Epoch 1', 'Epoch 2', 'Epoch 3', 'Epoch 4', 'Epoch 5'],
                    datasets: [{
                        label: 'Training Loss',
                        data: [0.5, 0.4, 0.3, 0.2, 0.1],
                        borderColor: 'rgb(75, 192, 192)',
                        tension: 0.1
                    }]
                }
            });
        </script>
    </div>
    """

@router.get("/metrics/validation")
async def get_validation_metrics() -> str:
    """Return validation metrics visualization HTML"""
    return """
    <div class="h-64 bg-white rounded-lg border p-4">
        <canvas id="validationChart"></canvas>
        <script>
            const ctxVal = document.getElementById('validationChart').getContext('2d');
            new Chart(ctxVal, {
                type: 'line',
                data: {
                    labels: ['Epoch 1', 'Epoch 2', 'Epoch 3', 'Epoch 4', 'Epoch 5'],
                    datasets: [{
                        label: 'Validation Accuracy',
                        data: [0.82, 0.85, 0.87, 0.89, 0.91],
                        borderColor: 'rgb(153, 102, 255)',
                        tension: 0.1
                    }]
                }
            });
        </script>
    </div>
    """

@router.get("/resources/{resource_type}")
async def get_resource_metrics(resource_type: str) -> str:
    """Return resource usage metrics"""
    metrics = {
        "storage": "Used: 250GB / 500GB",
        "compute": "Total: 120 hours",
        "costs": "Estimated: $156.50"
    }
    
    if resource_type not in metrics:
        raise HTTPException(status_code=404, detail="Resource type not found")
        
    return f"""
    <div class="text-2xl font-semibold text-gray-700">
        {metrics[resource_type]}
    </div>
    """

@router.get("/collaboration/activity")
async def get_team_activity() -> str:
    """Return team activity HTML"""
    activities = [
        {"user": "Alice", "action": "Updated model parameters", "time": "2h ago"},
        {"user": "Bob", "action": "Started new training run", "time": "4h ago"}
    ]
    
    return """
    <div class="space-y-4">
        """ + "".join([f"""
        <div class="flex items-center space-x-3">
            <div class="flex-shrink-0">
                <div class="h-8 w-8 rounded-full bg-gray-200"></div>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-900">{activity['user']}</p>
                <p class="text-sm text-gray-500">{activity['action']} - {activity['time']}</p>
            </div>
        </div>
        """ for activity in activities]) + """
    </div>
    """

@router.get("/collaboration/comments")
async def get_comments() -> str:
    """Return comments HTML"""
    comments = [
        {"user": "Alice", "text": "The model is performing well on the test set", "time": "2h ago"},
        {"user": "Bob", "text": "We should try adjusting the learning rate", "time": "4h ago"}
    ]
    
    return """
    <div class="space-y-4">
        """ + "".join([f"""
        <div class="bg-gray-50 rounded-lg p-4">
            <div class="flex items-center justify-between">
                <span class="text-sm font-medium text-gray-900">{comment['user']}</span>
                <span class="text-sm text-gray-500">{comment['time']}</span>
            </div>
            <p class="mt-1 text-sm text-gray-600">{comment['text']}</p>
        </div>
        """ for comment in comments]) + """
    </div>
    """

@router.get("/experiment-details/{experiment_id}")
async def experiment_details(experiment_id: str):
    return {"template": "pages/experiment/details.html"} 